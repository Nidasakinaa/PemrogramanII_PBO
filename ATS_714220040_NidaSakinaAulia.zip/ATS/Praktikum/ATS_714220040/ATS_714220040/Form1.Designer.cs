﻿namespace ATS_714220040
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblTitle = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnPilih = new System.Windows.Forms.Button();
            this.tbNPM = new System.Windows.Forms.TextBox();
            this.tbNama = new System.Windows.Forms.TextBox();
            this.tbAlamat = new System.Windows.Forms.TextBox();
            this.tbTahun = new System.Windows.Forms.TextBox();
            this.tbSmt = new System.Windows.Forms.TextBox();
            this.rbLaki = new System.Windows.Forms.RadioButton();
            this.rbPerempuan = new System.Windows.Forms.RadioButton();
            this.cbProdi = new System.Windows.Forms.ComboBox();
            this.gbKurikulum = new System.Windows.Forms.GroupBox();
            this.rbMerdeka = new System.Windows.Forms.RadioButton();
            this.rb2013 = new System.Windows.Forms.RadioButton();
            this.rb2006 = new System.Windows.Forms.RadioButton();
            this.gbMatkul = new System.Windows.Forms.GroupBox();
            this.cbManajemen = new System.Windows.Forms.CheckBox();
            this.cbSO = new System.Windows.Forms.CheckBox();
            this.cbPKN = new System.Windows.Forms.CheckBox();
            this.cbPA = new System.Windows.Forms.CheckBox();
            this.cbJK = new System.Windows.Forms.CheckBox();
            this.cbFisika = new System.Windows.Forms.CheckBox();
            this.cbPL = new System.Windows.Forms.CheckBox();
            this.cbP4 = new System.Windows.Forms.CheckBox();
            this.cbP3 = new System.Windows.Forms.CheckBox();
            this.cbP2 = new System.Windows.Forms.CheckBox();
            this.cbP1 = new System.Windows.Forms.CheckBox();
            this.cbMTK = new System.Windows.Forms.CheckBox();
            this.btnSimpan = new System.Windows.Forms.Button();
            this.btnBatal = new System.Windows.Forms.Button();
            this.epWarning = new System.Windows.Forms.ErrorProvider(this.components);
            this.epCorrect = new System.Windows.Forms.ErrorProvider(this.components);
            this.epWrong = new System.Windows.Forms.ErrorProvider(this.components);
            this.gbKurikulum.SuspendLayout();
            this.gbMatkul.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.epWarning)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.epCorrect)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.epWrong)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.Location = new System.Drawing.Point(345, 36);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(443, 29);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "PILIHAN MATA KULIAH MAHASISWA";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 131);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "NPM";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(55, 188);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 25);
            this.label2.TabIndex = 3;
            this.label2.Text = "Nama";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(55, 240);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(135, 25);
            this.label3.TabIndex = 5;
            this.label3.Text = "Jenis Kelamin";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(58, 288);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 25);
            this.label4.TabIndex = 8;
            this.label4.Text = "Alamat";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(632, 131);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(136, 25);
            this.label5.TabIndex = 10;
            this.label5.Text = "Program Studi";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(632, 188);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(161, 25);
            this.label6.TabIndex = 12;
            this.label6.Text = "Tahun Akademik";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(636, 240);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 25);
            this.label7.TabIndex = 14;
            this.label7.Text = "Semester";
            // 
            // btnPilih
            // 
            this.btnPilih.Location = new System.Drawing.Point(896, 308);
            this.btnPilih.Name = "btnPilih";
            this.btnPilih.Size = new System.Drawing.Size(213, 53);
            this.btnPilih.TabIndex = 16;
            this.btnPilih.Text = "Pilih Mata Kuliah";
            this.btnPilih.UseVisualStyleBackColor = true;
            this.btnPilih.Click += new System.EventHandler(this.btnPilih_Click);
            // 
            // tbNPM
            // 
            this.tbNPM.Location = new System.Drawing.Point(240, 131);
            this.tbNPM.Name = "tbNPM";
            this.tbNPM.Size = new System.Drawing.Size(291, 29);
            this.tbNPM.TabIndex = 2;
            this.tbNPM.TextChanged += new System.EventHandler(this.tbNPM_TextChanged);
            // 
            // tbNama
            // 
            this.tbNama.Location = new System.Drawing.Point(240, 188);
            this.tbNama.Name = "tbNama";
            this.tbNama.Size = new System.Drawing.Size(291, 29);
            this.tbNama.TabIndex = 4;
            this.tbNama.TextChanged += new System.EventHandler(this.tbNama_TextChanged);
            // 
            // tbAlamat
            // 
            this.tbAlamat.Location = new System.Drawing.Point(240, 288);
            this.tbAlamat.Multiline = true;
            this.tbAlamat.Name = "tbAlamat";
            this.tbAlamat.Size = new System.Drawing.Size(291, 73);
            this.tbAlamat.TabIndex = 9;
            this.tbAlamat.TextChanged += new System.EventHandler(this.tbAlamat_TextChanged);
            // 
            // tbTahun
            // 
            this.tbTahun.Location = new System.Drawing.Point(818, 184);
            this.tbTahun.Name = "tbTahun";
            this.tbTahun.Size = new System.Drawing.Size(291, 29);
            this.tbTahun.TabIndex = 13;
            this.tbTahun.TextChanged += new System.EventHandler(this.tbTahun_TextChanged);
            // 
            // tbSmt
            // 
            this.tbSmt.Location = new System.Drawing.Point(818, 240);
            this.tbSmt.Name = "tbSmt";
            this.tbSmt.Size = new System.Drawing.Size(291, 29);
            this.tbSmt.TabIndex = 15;
            this.tbSmt.TextChanged += new System.EventHandler(this.tbSmt_TextChanged);
            // 
            // rbLaki
            // 
            this.rbLaki.AutoSize = true;
            this.rbLaki.Location = new System.Drawing.Point(240, 235);
            this.rbLaki.Name = "rbLaki";
            this.rbLaki.Size = new System.Drawing.Size(109, 29);
            this.rbLaki.TabIndex = 6;
            this.rbLaki.TabStop = true;
            this.rbLaki.Text = "Laki-laki";
            this.rbLaki.UseVisualStyleBackColor = true;
            // 
            // rbPerempuan
            // 
            this.rbPerempuan.AutoSize = true;
            this.rbPerempuan.Location = new System.Drawing.Point(393, 233);
            this.rbPerempuan.Name = "rbPerempuan";
            this.rbPerempuan.Size = new System.Drawing.Size(138, 29);
            this.rbPerempuan.TabIndex = 7;
            this.rbPerempuan.TabStop = true;
            this.rbPerempuan.Text = "Perempuan";
            this.rbPerempuan.UseVisualStyleBackColor = true;
            // 
            // cbProdi
            // 
            this.cbProdi.FormattingEnabled = true;
            this.cbProdi.Items.AddRange(new object[] {
            "",
            "D3 Teknik Informatika",
            "D4 Teknik Informatika"});
            this.cbProdi.Location = new System.Drawing.Point(818, 122);
            this.cbProdi.Name = "cbProdi";
            this.cbProdi.Size = new System.Drawing.Size(291, 32);
            this.cbProdi.TabIndex = 11;
            this.cbProdi.SelectedIndexChanged += new System.EventHandler(this.cbProdi_TextChanged);
            // 
            // gbKurikulum
            // 
            this.gbKurikulum.Controls.Add(this.rbMerdeka);
            this.gbKurikulum.Controls.Add(this.rb2013);
            this.gbKurikulum.Controls.Add(this.rb2006);
            this.gbKurikulum.Location = new System.Drawing.Point(40, 446);
            this.gbKurikulum.Name = "gbKurikulum";
            this.gbKurikulum.Size = new System.Drawing.Size(309, 226);
            this.gbKurikulum.TabIndex = 17;
            this.gbKurikulum.TabStop = false;
            this.gbKurikulum.Text = "Kurikulum Pilihan";
            // 
            // rbMerdeka
            // 
            this.rbMerdeka.AutoSize = true;
            this.rbMerdeka.Location = new System.Drawing.Point(7, 135);
            this.rbMerdeka.Name = "rbMerdeka";
            this.rbMerdeka.Size = new System.Drawing.Size(206, 29);
            this.rbMerdeka.TabIndex = 2;
            this.rbMerdeka.TabStop = true;
            this.rbMerdeka.Text = "Kurikulum Merdeka";
            this.rbMerdeka.UseVisualStyleBackColor = true;
            this.rbMerdeka.CheckedChanged += new System.EventHandler(this.rbMerdeka_CheckedChanged);
            // 
            // rb2013
            // 
            this.rb2013.AutoSize = true;
            this.rb2013.Location = new System.Drawing.Point(7, 93);
            this.rb2013.Name = "rb2013";
            this.rb2013.Size = new System.Drawing.Size(173, 29);
            this.rb2013.TabIndex = 1;
            this.rb2013.TabStop = true;
            this.rb2013.Text = "Kurikulum 2013";
            this.rb2013.UseVisualStyleBackColor = true;
            this.rb2013.CheckedChanged += new System.EventHandler(this.rb2013_CheckedChanged);
            // 
            // rb2006
            // 
            this.rb2006.AutoSize = true;
            this.rb2006.Location = new System.Drawing.Point(7, 46);
            this.rb2006.Name = "rb2006";
            this.rb2006.Size = new System.Drawing.Size(173, 29);
            this.rb2006.TabIndex = 0;
            this.rb2006.TabStop = true;
            this.rb2006.Text = "Kurikulum 2006";
            this.rb2006.UseVisualStyleBackColor = true;
            this.rb2006.CheckedChanged += new System.EventHandler(this.rb2006_CheckedChanged);
            // 
            // gbMatkul
            // 
            this.gbMatkul.Controls.Add(this.cbManajemen);
            this.gbMatkul.Controls.Add(this.cbSO);
            this.gbMatkul.Controls.Add(this.cbPKN);
            this.gbMatkul.Controls.Add(this.cbPA);
            this.gbMatkul.Controls.Add(this.cbJK);
            this.gbMatkul.Controls.Add(this.cbFisika);
            this.gbMatkul.Controls.Add(this.cbPL);
            this.gbMatkul.Controls.Add(this.cbP4);
            this.gbMatkul.Controls.Add(this.cbP3);
            this.gbMatkul.Controls.Add(this.cbP2);
            this.gbMatkul.Controls.Add(this.cbP1);
            this.gbMatkul.Controls.Add(this.cbMTK);
            this.gbMatkul.Location = new System.Drawing.Point(375, 446);
            this.gbMatkul.Name = "gbMatkul";
            this.gbMatkul.Size = new System.Drawing.Size(761, 235);
            this.gbMatkul.TabIndex = 18;
            this.gbMatkul.TabStop = false;
            this.gbMatkul.Text = "Mata Kuliah Pilihan";
            // 
            // cbManajemen
            // 
            this.cbManajemen.AutoSize = true;
            this.cbManajemen.Location = new System.Drawing.Point(504, 177);
            this.cbManajemen.Name = "cbManajemen";
            this.cbManajemen.Size = new System.Drawing.Size(261, 29);
            this.cbManajemen.TabIndex = 11;
            this.cbManajemen.Text = "Manajemen Rantai Pasok";
            this.cbManajemen.UseVisualStyleBackColor = true;
            // 
            // cbSO
            // 
            this.cbSO.AutoSize = true;
            this.cbSO.Location = new System.Drawing.Point(507, 128);
            this.cbSO.Name = "cbSO";
            this.cbSO.Size = new System.Drawing.Size(172, 29);
            this.cbSO.TabIndex = 10;
            this.cbSO.Text = "Sistem Operasi";
            this.cbSO.UseVisualStyleBackColor = true;
            // 
            // cbPKN
            // 
            this.cbPKN.AutoSize = true;
            this.cbPKN.Location = new System.Drawing.Point(204, 176);
            this.cbPKN.Name = "cbPKN";
            this.cbPKN.Size = new System.Drawing.Size(301, 29);
            this.cbPKN.TabIndex = 7;
            this.cbPKN.Text = "Pendidikan Kewarganegaraan";
            this.cbPKN.UseVisualStyleBackColor = true;
            // 
            // cbPA
            // 
            this.cbPA.AutoSize = true;
            this.cbPA.Location = new System.Drawing.Point(207, 128);
            this.cbPA.Name = "cbPA";
            this.cbPA.Size = new System.Drawing.Size(203, 29);
            this.cbPA.TabIndex = 6;
            this.cbPA.Text = "Pendidikan Agama";
            this.cbPA.UseVisualStyleBackColor = true;
            // 
            // cbJK
            // 
            this.cbJK.AutoSize = true;
            this.cbJK.Location = new System.Drawing.Point(507, 81);
            this.cbJK.Name = "cbJK";
            this.cbJK.Size = new System.Drawing.Size(204, 29);
            this.cbJK.TabIndex = 9;
            this.cbJK.Text = "Jaringan Komputer";
            this.cbJK.UseVisualStyleBackColor = true;
            // 
            // cbFisika
            // 
            this.cbFisika.AutoSize = true;
            this.cbFisika.Location = new System.Drawing.Point(206, 81);
            this.cbFisika.Name = "cbFisika";
            this.cbFisika.Size = new System.Drawing.Size(89, 29);
            this.cbFisika.TabIndex = 5;
            this.cbFisika.Text = "Fisika";
            this.cbFisika.UseVisualStyleBackColor = true;
            // 
            // cbPL
            // 
            this.cbPL.AutoSize = true;
            this.cbPL.Location = new System.Drawing.Point(507, 33);
            this.cbPL.Name = "cbPL";
            this.cbPL.Size = new System.Drawing.Size(199, 29);
            this.cbPL.TabIndex = 8;
            this.cbPL.Text = "Pengantar Logistik";
            this.cbPL.UseVisualStyleBackColor = true;
            // 
            // cbP4
            // 
            this.cbP4.AutoSize = true;
            this.cbP4.Location = new System.Drawing.Point(206, 33);
            this.cbP4.Name = "cbP4";
            this.cbP4.Size = new System.Drawing.Size(177, 29);
            this.cbP4.TabIndex = 4;
            this.cbP4.Text = "Pemrograman 4";
            this.cbP4.UseVisualStyleBackColor = true;
            // 
            // cbP3
            // 
            this.cbP3.AutoSize = true;
            this.cbP3.Location = new System.Drawing.Point(18, 175);
            this.cbP3.Name = "cbP3";
            this.cbP3.Size = new System.Drawing.Size(177, 29);
            this.cbP3.TabIndex = 3;
            this.cbP3.Text = "Pemorgraman 3";
            this.cbP3.UseVisualStyleBackColor = true;
            this.cbP3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // cbP2
            // 
            this.cbP2.AutoSize = true;
            this.cbP2.Location = new System.Drawing.Point(18, 128);
            this.cbP2.Name = "cbP2";
            this.cbP2.Size = new System.Drawing.Size(177, 29);
            this.cbP2.TabIndex = 2;
            this.cbP2.Text = "Pemrograman 2";
            this.cbP2.UseVisualStyleBackColor = true;
            // 
            // cbP1
            // 
            this.cbP1.AutoSize = true;
            this.cbP1.Location = new System.Drawing.Point(18, 81);
            this.cbP1.Name = "cbP1";
            this.cbP1.Size = new System.Drawing.Size(177, 29);
            this.cbP1.TabIndex = 1;
            this.cbP1.Text = "Pemrograman 1";
            this.cbP1.UseVisualStyleBackColor = true;
            // 
            // cbMTK
            // 
            this.cbMTK.AutoSize = true;
            this.cbMTK.Location = new System.Drawing.Point(18, 33);
            this.cbMTK.Name = "cbMTK";
            this.cbMTK.Size = new System.Drawing.Size(139, 29);
            this.cbMTK.TabIndex = 0;
            this.cbMTK.Text = "Matematika";
            this.cbMTK.UseVisualStyleBackColor = true;
            // 
            // btnSimpan
            // 
            this.btnSimpan.Location = new System.Drawing.Point(258, 751);
            this.btnSimpan.Name = "btnSimpan";
            this.btnSimpan.Size = new System.Drawing.Size(140, 54);
            this.btnSimpan.TabIndex = 19;
            this.btnSimpan.Text = "Simpan";
            this.btnSimpan.UseVisualStyleBackColor = true;
            this.btnSimpan.Click += new System.EventHandler(this.btnSimpan_Click);
            // 
            // btnBatal
            // 
            this.btnBatal.Location = new System.Drawing.Point(469, 751);
            this.btnBatal.Name = "btnBatal";
            this.btnBatal.Size = new System.Drawing.Size(140, 54);
            this.btnBatal.TabIndex = 20;
            this.btnBatal.Text = "Batal";
            this.btnBatal.UseVisualStyleBackColor = true;
            this.btnBatal.Click += new System.EventHandler(this.btnBatal_Click);
            // 
            // epWarning
            // 
            this.epWarning.ContainerControl = this;
            this.epWarning.Icon = ((System.Drawing.Icon)(resources.GetObject("epWarning.Icon")));
            // 
            // epCorrect
            // 
            this.epCorrect.ContainerControl = this;
            this.epCorrect.Icon = ((System.Drawing.Icon)(resources.GetObject("epCorrect.Icon")));
            // 
            // epWrong
            // 
            this.epWrong.ContainerControl = this;
            this.epWrong.Icon = ((System.Drawing.Icon)(resources.GetObject("epWrong.Icon")));
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1176, 842);
            this.Controls.Add(this.btnBatal);
            this.Controls.Add(this.btnSimpan);
            this.Controls.Add(this.gbMatkul);
            this.Controls.Add(this.gbKurikulum);
            this.Controls.Add(this.cbProdi);
            this.Controls.Add(this.rbPerempuan);
            this.Controls.Add(this.rbLaki);
            this.Controls.Add(this.tbSmt);
            this.Controls.Add(this.tbTahun);
            this.Controls.Add(this.tbAlamat);
            this.Controls.Add(this.tbNama);
            this.Controls.Add(this.tbNPM);
            this.Controls.Add(this.btnPilih);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblTitle);
            this.Name = "Form1";
            this.Text = "Form Pilihan Matkul";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbKurikulum.ResumeLayout(false);
            this.gbKurikulum.PerformLayout();
            this.gbMatkul.ResumeLayout(false);
            this.gbMatkul.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.epWarning)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.epCorrect)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.epWrong)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnPilih;
        private System.Windows.Forms.TextBox tbNPM;
        private System.Windows.Forms.TextBox tbNama;
        private System.Windows.Forms.TextBox tbAlamat;
        private System.Windows.Forms.TextBox tbTahun;
        private System.Windows.Forms.TextBox tbSmt;
        private System.Windows.Forms.RadioButton rbLaki;
        private System.Windows.Forms.RadioButton rbPerempuan;
        private System.Windows.Forms.ComboBox cbProdi;
        private System.Windows.Forms.GroupBox gbKurikulum;
        private System.Windows.Forms.RadioButton rbMerdeka;
        private System.Windows.Forms.RadioButton rb2013;
        private System.Windows.Forms.RadioButton rb2006;
        private System.Windows.Forms.GroupBox gbMatkul;
        private System.Windows.Forms.CheckBox cbP2;
        private System.Windows.Forms.CheckBox cbP1;
        private System.Windows.Forms.CheckBox cbMTK;
        private System.Windows.Forms.CheckBox cbP3;
        private System.Windows.Forms.CheckBox cbManajemen;
        private System.Windows.Forms.CheckBox cbSO;
        private System.Windows.Forms.CheckBox cbPKN;
        private System.Windows.Forms.CheckBox cbPA;
        private System.Windows.Forms.CheckBox cbJK;
        private System.Windows.Forms.CheckBox cbFisika;
        private System.Windows.Forms.CheckBox cbPL;
        private System.Windows.Forms.CheckBox cbP4;
        private System.Windows.Forms.Button btnSimpan;
        private System.Windows.Forms.Button btnBatal;
        private System.Windows.Forms.ErrorProvider epWarning;
        private System.Windows.Forms.ErrorProvider epCorrect;
        private System.Windows.Forms.ErrorProvider epWrong;
    }
}

