﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATS_714220040
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            this.Size = new Size(680, 250);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btnPilih_Click(object sender, EventArgs e)
        {
            string jenisKelamin = "";
            string errorMessage = "";

            if (string.IsNullOrEmpty(tbNPM.Text))
            {
                errorMessage += "NPM Tidak Boleh Kosong!\n";
            }
            if (string.IsNullOrEmpty(tbNama.Text))
            {
                errorMessage += "Nama tidak boleh Kosong!\n";
            }
            if (!rbLaki.Checked && !rbPerempuan.Checked)
            {
                errorMessage += "Pilih Jenis Kelamin!\n";
            }
            if (string.IsNullOrEmpty(tbAlamat.Text))
            {
                errorMessage += "Alamat tidak boleh kosong!\n";
            }
            if (cbProdi.SelectedIndex == -1)
            {
                errorMessage += "Pilih Prodi!\n";
            }
            if (string.IsNullOrEmpty(tbTahun.Text))
            {
                errorMessage += "Tahun Akademik tidak boleh Kosong!\n";
            }
            if (string.IsNullOrEmpty(tbSmt.Text))
            {
                errorMessage += "Semester tidak boleh kosong!\n";
            }
            if (string.IsNullOrEmpty(errorMessage))
            {
                MessageBox.Show("Lengkapi Data!", "Informasi Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Size = new Size(650, 556);
                gbMatkul.Enabled = false;
            }
            else
            {
                MessageBox.Show(errorMessage, "Informasi Data", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void tbNPM_TextChanged(object sender, EventArgs e)
        {
            if (tbNPM.Text == "")
            {
                epWarning.SetError(tbNPM, "NPM harus diisi!");
                epWrong.SetError(tbNPM, "");
                epCorrect.SetError(tbNPM, "");
            }
            else
            {
                if (!tbNPM.Text.All(Char.IsNumber))
                {
                    epWarning.SetError(tbNPM, "");
                    epWrong.SetError(tbNPM, "NPM Harus Dalam Bentuk Angka!");
                    epCorrect.SetError(tbNPM, "");
                }
                else
                {
                    if (tbNPM.Text.Length != 9)
                    {
                        epWarning.SetError(tbNPM, "NPM Harus Ada 9 Digit!");
                        epWrong.SetError(tbNPM, "");
                        epCorrect.SetError(tbNPM, "");
                    }
                    else
                    {
                        if ((tbNPM.Text).All(char.IsNumber))
                        {
                            epWarning.SetError(tbNPM, "");
                            epWrong.SetError(tbNPM, "");
                            epCorrect.SetError(tbNPM, "NPM Benar!");
                        }

                    }
                }
            }
        }

        private void tbNama_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tbNama.Text) || string.IsNullOrWhiteSpace(tbNama.Text))
            {
                epWarning.SetError(tbNama, "Nama harus diisi!");
                epWrong.SetError(tbNama, "");
                epCorrect.SetError(tbNama, "");
            }
            else
            {
                if (tbNama.Text.All(c => char.IsLetter(c) || char.IsWhiteSpace(c)))
                {
                    epWarning.SetError(tbNama, "");
                    epWrong.SetError(tbNama, "");
                    epCorrect.SetError(tbNama, "Nama Benar!");
                }
                else
                {
                     epWarning.SetError(tbNama, "");
                     epWrong.SetError(tbNama, "Nama Hanya Berupa Huruf!");
                     epCorrect.SetError(tbNama, "");
                        
                }
            }
        }

        private void cbProdi_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(cbProdi.Text))
            {
                epWarning.SetError(cbProdi, "Isi Program Studi!");
                epWrong.SetError(cbProdi, "");
                epCorrect.SetError(cbProdi, "");
            }
            else
            {
                if (cbProdi.Text != "D3 Teknik Informatika" && cbProdi.Text != "D4 Teknik Informatika")
                {
                    epWarning.SetError(cbProdi, "");
                    epWrong.SetError(cbProdi, "Program studi salah!");
                    epCorrect.SetError(cbProdi, "");
                }
                else
                {
                    epWarning.SetError(cbProdi, "");
                    epWrong.SetError(cbProdi, "");
                    epCorrect.SetError(cbProdi, "Program Studi Benar!");
                }
            }
        }

        private void tbTahun_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(tbTahun.Text, @"^\d{4}/\d{4}$")) 
            {
                epWarning.SetError(tbTahun, "");
                epWrong.SetError(tbTahun, "");
                epCorrect.SetError(tbTahun, "Tahun Akademi Salah!");
            }
            else
            {
                epWarning.SetError(tbTahun, "");
                epWrong.SetError(tbTahun, "Tahun Akademik Studi Salah!\nContoh : 2022/2023");
                epCorrect.SetError(tbTahun, "");
            }
        }

        private void tbSmt_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tbSmt.Text))
            {
                epWarning.SetError(tbSmt, "Semester tidak boieh Kosong!");
                epWrong.SetError(tbSmt, "");
                epCorrect.SetError(tbSmt, "");
            }
            else
            {
                if (int.TryParse(tbSmt.Text, out int InputSmt) && InputSmt > 0 && InputSmt <= 10)
                {
                    epWarning.SetError(tbSmt, "");
                    epWrong.SetError(tbSmt, "");
                    epCorrect.SetError(tbSmt, "Semester Benar!");
                }
                else
                {
                    epWarning.SetError(tbSmt, "Semester hanya berupa angka dari 1 sampai dengan 10!");
                    epWrong.SetError(tbSmt, "");
                    epCorrect.SetError(tbSmt, "");
                }
            }
        }

        private void tbAlamat_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(tbAlamat.Text))
            {
                epWarning.SetError(tbAlamat, "Alamat tidak boieh Kosong!");
                epWrong.SetError(tbAlamat, "");
                epCorrect.SetError(tbAlamat, "");
            }
            else
            {
                epWarning.SetError(tbAlamat, "");
                epWrong.SetError(tbAlamat, "");
                epCorrect.SetError(tbAlamat, "Alamat sudah terisi!");
            }
        }

        private void rb2006_CheckedChanged(object sender, EventArgs e)
        {
            gbMatkul.Enabled = true;
            if (rb2006.Checked)
            {
                cbPL.Enabled = false;
                cbPL.Checked = false;
                cbManajemen.Enabled = false;
                cbManajemen.Checked = false;
                cbMTK.Enabled = true;
                cbMTK.Checked = true;
                cbP1.Enabled = true;
                cbP2.Enabled = true;
                cbP3.Enabled = true;
                cbP4.Enabled = true;
                cbFisika.Enabled = true;
                cbPA.Enabled = true;
                cbPKN.Enabled = true;
                cbJK.Enabled = true;
                cbSO.Enabled = true;
            }
        }

        private void rb2013_CheckedChanged(object sender, EventArgs e)
        {
            gbMatkul.Enabled = true;
            if (rb2013.Checked)
            {
                cbPL.Checked = true;
                cbManajemen.Checked = true;
                cbMTK.Checked = true;
                cbP1.Enabled = true;
                cbP2.Enabled = true;
                cbP3.Enabled = true;
                cbP4.Enabled = true;
                cbFisika.Enabled = false;
                cbFisika.Checked = false;
                cbPA.Enabled = true;
                cbPKN.Enabled = false;
                cbPKN.Checked = false;
                cbJK.Enabled = true;
                cbSO.Enabled = true;
            }
        }

        private void rbMerdeka_CheckedChanged(object sender, EventArgs e)
        {
            gbMatkul.Enabled = true;
            if (rbMerdeka.Checked)
            {
                cbPL.Enabled = false;
                cbPL.Checked = false;
                cbManajemen.Enabled = true;
                cbMTK.Checked = false;
                cbMTK.Enabled = false;
                cbP1.Enabled = true;
                cbP2.Enabled = true;
                cbP3.Enabled = true;
                cbP4.Enabled = true;
                cbFisika.Enabled = false;
                cbFisika.Checked = false;
                cbPA.Enabled = true;
                cbPKN.Enabled = true;
                cbJK.Enabled = true;
                cbSO.Enabled = true;
            }
        }

        private void btnSimpan_Click(object sender, EventArgs e)
        {
            string jenisKelamin = "";

            if (rbLaki.Checked == true)
            {
                jenisKelamin = "Laki-laki";
            }
            else if (rbPerempuan.Checked == true)
            {
                jenisKelamin = "Perempuan";
            }

            string Kurikulum = "";
            string Matkul = "";

            if (rb2006.Checked == true)
            {
                Kurikulum = "Kurikulum 2006";
            }
            else if (rb2013.Checked == true)
            {
                Kurikulum = "Kurikulum 2013";
            }
            else if (rbMerdeka.Checked == true)
            {
                Kurikulum = "Kurikulum Merdeka";
            }
            else
            {
                MessageBox.Show("Pilih Kurikulum!", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (cbMTK.Checked == true)
            {
                Matkul = "Matematika";
            }
            if (cbP1.Checked == true)
            {
                Matkul = "Pemrograman 1";
            }
            if (cbP2.Checked == true)
            {
                Matkul = "Pemrograman 2";
            }
            if (cbP3.Checked == true)
            {
                Matkul = "Pemrograman 4";
            }
            if (cbP4.Checked == true)
            {
                Matkul = "Pemrograman 4";
            }
            if (cbFisika.Checked == true)
            {
                Matkul = "Fisika";
            }
            if (cbPA.Checked == true)
            {
                Matkul = "Pendidikan Agama";
            }
            if (cbPKN.Checked == true)
            {
                Matkul = "Pendidikan Kewarganegaraan";
            }
            if (cbPL.Checked == true)
            {
                Matkul = "Pengantar Logistik";
            }
            if (cbJK.Checked == true)
            {
                Matkul = "Jaringan Komputer";
            }
            if (cbSO.Checked == true)
            {
                Matkul = "Sistem Operasi";
            }
            if (cbManajemen.Checked == true)
            {
                Matkul = "Manajemen Rantai Pasok";
            }

            Matkul = Matkul.TrimEnd(',', ' ');

            if (string.IsNullOrWhiteSpace(Matkul))
            {
                MessageBox.Show("Pilih Mata Kuliah!", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            MessageBox.Show("NPM : " + tbNPM.Text +
                "\nNama : " + tbNama.Text +
                "\nJenis Kelamin : " + jenisKelamin +
                "\nAlamat : " + tbAlamat.Text +
                "\nProgram Studi : " + cbProdi.Text +
                "\nTahun Akademik : " + tbTahun.Text +
                "\nSemester : " + tbSmt.Text +
                "\n-----------------------------------" +
                "\nKurikulum : " + Kurikulum +
                "\nMata Kuliah : " + Matkul,
                "Informasi Data Submit", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnBatal_Click(object sender, EventArgs e)
        {
            foreach (Control control in Controls)
            {
                if (control is TextBox textBox)
                {
                        textBox.Text = string.Empty;
                        epWarning.SetError(textBox, "");
                        epWrong.SetError(textBox, "");
                        epCorrect.SetError(textBox, "");
                }
                else if(control is RadioButton radioButton)
                {
                    radioButton.Checked = false;
                }
                else if (control is ComboBox comboBox)
                {
                    comboBox.SelectedIndex = -1;
                    epWarning.SetError(comboBox, "");
                    epWrong.SetError(comboBox, "");
                    epCorrect.SetError(comboBox, "");
                }
                else if (control is GroupBox groupBox)
                {
                    foreach (Control innerControl in groupBox.Controls)
                    {
                        if (innerControl is RadioButton innerRadioButton)
                        {
                            innerRadioButton.Checked = false;
                        }
                        else if (innerControl is CheckBox innerCheckBox)
                        {
                            innerCheckBox.Checked = false;
                        }
                    }
                }
            }
            this.Size = new Size(670, 550);
        }
    }
}
